package sk.train.ma.strategy.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import sk.train.ma.strategy.verwaltung.MitarbeiterVerwaltung;

class Mitarbeiterverwaltung_KonstruktorTest {

	@BeforeAll
	static void beforeAll() {

	}

	@AfterAll
	static void afterAll() {

	}

	@BeforeEach
	void setUp() {

	}

	//Whitebox-Test unter Nutzung der getMap-Methode
	@Test
	final void testMitarbeiterVerwaltungKonstruktor() {
		MitarbeiterVerwaltung mv = new MitarbeiterVerwaltung();
		assertNotNull(mv, "Konstruktor inkorrekt");
		assertNotNull(mv.getMap(), "Interne Map wurde nicht bereit gestellt");
		assertTrue(mv.getMap().size()>0 , "Map ist leer");
	}

}
