Das bisherige sk.train.x11_07_JPA_Spring_SpringBoot_Solution mit einfachem 
Rest-Frontend, welches die CRUD-Operationen abdeckt und JSON liefert.