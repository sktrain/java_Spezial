Rest mit JPA, Spring Boot und XML-MessageFormat mit Jackson,
sowie OpenAPI_Generierung inklusive Swagger-UI

http://localhost:8080/v3/api-docs default-URL für Open-Api-Doc
http://localhost:8080/swagger-ui/index.html default-URL für Swagger-UI

