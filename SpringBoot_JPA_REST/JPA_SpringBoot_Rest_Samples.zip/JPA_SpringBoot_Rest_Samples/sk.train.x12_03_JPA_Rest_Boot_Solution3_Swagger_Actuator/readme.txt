Rest mit JPA, Spring Boot und XML-MessageFormat mit Jackson,
OpenAPI_Generierung inklusive Swagger-UI
sowie Actuator-Einbindung zur Überwachung der Anwendung 
(inklusive eigener Infos über Info-Endpunkt)

http://localhost:8080/v3/api-docs default-URL für Open-Api-Doc
http://localhost:8080/swagger-ui/index.html default-URL für Swagger-UI

http://localhost:8080/actuator	default-URL für Actuator-Endpunkte