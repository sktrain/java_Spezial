package appl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import beans.MathServiceImpl;
import ifaces.DiffService;
import ifaces.MathService;
import ifaces.SumService;
import somewhere.SumDiffConfiguration;

@Configuration
@Import(SumDiffConfiguration.class)  // nur noetig, wenn package nicht in scan-packages enthalten
public class ApplConfig {

	public ApplConfig() {
	}
	
	@Autowired
	private SumService sumService;

	@Autowired
	private DiffService diffService;

	@Bean 
	public MathService getMathService() {
		return new MathServiceImpl(this.sumService, this.diffService);
	}
}
