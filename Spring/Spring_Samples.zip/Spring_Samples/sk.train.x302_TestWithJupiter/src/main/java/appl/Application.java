package appl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import ifaces.MathService;
import ifaces.SumService;

public class Application {
	public static void main(String[] args) {
		try (final ClassPathXmlApplicationContext ctx = 
				new ClassPathXmlApplicationContext("spring.xml")) 
		{
			final MathService mathService1 = ctx.getBean(MathService.class);
			final MathService mathService2 = ctx.getBean(MathService.class);
			//final MathService mathService = (MathService) ctx.getBean("mathService");
			final MathService mathService = (MathService) ctx.getBean("math");
			
			System.out.println(mathService1 == mathService2);
			
			System.out.println(mathService1.sum(40, 2));
			System.out.println(mathService2.diff(80, 3));
			
			ctx.getBean("sumService1", SumService.class);
		}
	}
}
