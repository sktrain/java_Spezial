package beans;

import ifaces.Calculator;

public class CalculatorImpl implements Calculator {
	
	private int value;
	
	public CalculatorImpl() {
	}
	
	@Override
	public void add(int value) {
		this.value += value;
	}
	
	@Override
	public void subtract(int value) {
		this.value -= value;
	}
	
	@Override
	public int getValue() {
		return this.value;
	}
}
