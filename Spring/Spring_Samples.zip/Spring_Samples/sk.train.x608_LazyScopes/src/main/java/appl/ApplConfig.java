package appl;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

import beans.CalculatorImpl;
import beans.MathServiceImpl;
import ifaces.Calculator;
import ifaces.MathService;

@Configuration
public class ApplConfig {

	public ApplConfig() {
	}
	
	@Bean
	@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
	public MathService getMathService() {
		return new MathServiceImpl();
	}

	@Bean
	@Lazy
	@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
	public Calculator getCalculator() {
		return new CalculatorImpl();
	}
}
