package appl;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import ifaces.Calculator;
import ifaces.MathService;

public class Application {
	public static void main(String[] args) {
		try (final AnnotationConfigApplicationContext ctx = 
				new AnnotationConfigApplicationContext("beans")) {
			
			
			boolean b = ctx.isSingleton("mathServiceImpl");
			System.out.println(b);
			b = ctx.isPrototype("mathServiceImpl");
			System.out.println(b);
			
			final MathService mathService1 = ctx.getBean(MathService.class);
			final MathService mathService2 = ctx.getBean(MathService.class);
			System.out.println(mathService1 == mathService2);
			
			final Calculator calculator1 = ctx.getBean(Calculator.class);
			final Calculator calculator2 = ctx.getBean(Calculator.class);
			System.out.println(calculator1 == calculator2);
			
			calculator1.add(40);
			calculator2.add(80);
			calculator1.add(2);
			calculator2.subtract(3);
			System.out.println(calculator1.getValue());
			System.out.println(calculator2.getValue());
		}
	}
}
