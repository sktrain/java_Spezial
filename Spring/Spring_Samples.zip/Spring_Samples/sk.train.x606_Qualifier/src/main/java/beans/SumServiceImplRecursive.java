package beans;

import ifaces.SumService;

public class SumServiceImplRecursive implements SumService {
	
	public SumServiceImplRecursive() { 
	}
	
	@Override
	public int sum(int x, int y) {
		return y == 0 ? x : 1 + sum(x, y - 1);
	}
}
