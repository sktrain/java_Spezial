package appl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import beans.MathServiceImpl;
import ifaces.DiffService;
import ifaces.MathService;
import ifaces.SumService;

@Configuration
public class ApplConfigMath {

	public ApplConfigMath() {
	}
	
	@Autowired
	@Qualifier("sumServiceRecursive") 
	private SumService sumService;

	@Autowired
	private DiffService diffService;

//	@Autowired
//	public void setHelperServices(@Qualifier("sumServiceRecursive") SumService sumService, DiffService diffService) {
//		this.sumService = sumService;
//		this.diffService = diffService;
//	}

	@Bean 
	public MathService mathService() {
		return new MathServiceImpl(this.sumService, this.diffService);
	}
}
