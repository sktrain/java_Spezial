create table account (
	nr integer,
	balance integer,
	primary key (nr)
);