package appl;


public class Application {
	public static void main(String[] args) {
		
		//AnnotationContext hochziehen
		
		//Musiker bzw. Performer geben lassen
		//möglichst Gitarist und Klavierspieler
		
		//perform aufrufen
	}
}
