package ifaces;

public interface Performer {
	public abstract void perform();
}
