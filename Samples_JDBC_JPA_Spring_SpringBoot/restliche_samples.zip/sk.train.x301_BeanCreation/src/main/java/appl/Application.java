package appl;



import org.springframework.context.support.ClassPathXmlApplicationContext;

import ifaces.DiffService;
import ifaces.SumService;

public class Application {
	public static void main(String[] args) throws InterruptedException {
		try (final ClassPathXmlApplicationContext ctx = 
				new ClassPathXmlApplicationContext("spring.xml")) {
			
//			final SumService sumService1 = ctx.getBean(SumService.class,"sumService");
//			final SumService sumService2 = ctx.getBean(SumService.class, "sumService2");
			
			SumService sumService1 = (SumService) ctx.getBean("sumService");
			SumService sumService2 = (SumService) ctx.getBean("sumService2");
			
			
			System.out.println(sumService1 == sumService2);
			
			System.out.println(sumService1.sum(40, 2));
			System.out.println(sumService2.sum(80, 3));
			
			//Thread.sleep(10_000);

			final DiffService diffService = ctx.getBean(DiffService.class);
			System.out.println(diffService.diff(80, 3));
			
		}
	}
}
