package appl;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import domain.Account;
import jn.util.DBStatus;

public class Application {
	public static void main(String[] args) {
		
		try (final AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(ApplConfig.class)) {
			
			final JdbcTemplate template = ctx.getBean(JdbcTemplate.class);
			try {
				Connection connection = template.getDataSource().getConnection();
				DBStatus.showState(connection, "before");
				demo(template);
				DBStatus.showState(connection, "after");
			} catch (final DataRetrievalFailureException e) {
				System.out.println(e);
			}
			catch (final DataIntegrityViolationException e) {
				System.out.println(e);
			}
			catch (final Exception e) {
				System.out.println(e);
			}
		}
	}

	private static void demo(final JdbcTemplate template) {
		insertAccount(template, new Account(4711));
		insertAccount(template, new Account(4712));
		final Account account1 = findAccount(template, 4711);
		account1.setBalance(account1.getBalance() + 5000);
		updateAccount(template, account1);
		final Account account2 = findAccount(template, 4712);
		account2.setBalance(account2.getBalance() + 6000);
		updateAccount(template, account2);
		for (final Account account : findAllAccounts(template))
			System.out.println(account);
		deleteAccount(template, account1);
	}

	private static void insertAccount(JdbcTemplate template, Account account) {
		final String sql = "insert into account (number, balance) values (?, ?)";
		final Object result = template.update(sql, account.getNumber(), account.getBalance());
		if ((Integer) result != 1)
			throw new DataRetrievalFailureException(account.toString());
	}

	private static void updateAccount(JdbcTemplate template, Account account) {
		final String sql = "update account set balance = ? where number = ?";
		final Object result = template.update(sql, account.getBalance(), account.getNumber());
		if ((Integer) result != 1)
			throw new DataRetrievalFailureException(account.toString());
	}

	private static void deleteAccount(JdbcTemplate template, Account account) {
		final String sql = "delete from account where number = ?";
		final Object result = template.update(sql, account.getNumber());
		if ((Integer) result != 1)
			throw new DataRetrievalFailureException(account.toString());
	}

	private static RowMapper<Account> mapper = (rs, rowNumber) -> {
		final Account a = new Account();
		a.setNumber(rs.getInt(1));
		a.setBalance(rs.getInt(2));
		return a;
	};

	private static Account findAccount(JdbcTemplate template, int number) {
		final String sql = "select number, balance from account where number = ?";
		return template.queryForObject(sql, mapper, number);
	}

	private static List<Account> findAllAccounts(JdbcTemplate template) {
		final String sql = "select number, balance from account";
		return template.query(sql, mapper);
	}
}
