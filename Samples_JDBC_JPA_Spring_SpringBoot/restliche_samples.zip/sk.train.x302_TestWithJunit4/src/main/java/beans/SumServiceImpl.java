package beans;

import ifaces.SumService;

public class SumServiceImpl implements SumService {
	public SumServiceImpl() { 
	}
	@Override
	public int sum(int x, int y) {
		return x + y;
	}
}
