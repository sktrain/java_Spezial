package appl;

import ifaces.MathService;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.springframework.test.util.AssertionErrors.assertNotNull;

public class ApplicationNoSpringSupportTest {

    private static ClassPathXmlApplicationContext ctx;

    @BeforeAll
    static void beforeAll() {
        ctx = new ClassPathXmlApplicationContext("spring.xml");
    }

    @Test
        //Jupiter: non-public Test-Methods are allowed
    void contextLoads() {
        assertNotNull("Context wurde nicht geladen", ctx);
    }

    @Test  //Jupiter: Spring DI for Test-Methods is possible with Parameter-Injection
    public void MathServiceTest() {
        final MathService mathService1 = ctx.getBean(MathService.class);
        assertEquals(42, mathService1.sum(40, 2));
        assertEquals(38, mathService1.diff(40, 2));
    }

    @Test
    public void MathServiceSingletonTest() {
        final MathService mathService1 = ctx.getBean(MathService.class);
        final MathService mathService2 = ctx.getBean(MathService.class);
        assertSame(mathService1, mathService2);

    }


}
