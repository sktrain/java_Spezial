package beans;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ifaces.SumService;

public class SumServiceImpl implements SumService {
	
	private static Logger logger = LoggerFactory.getLogger("sk.train");
	
	public SumServiceImpl() { 
		logger.info("SumServiceImpl.Konstruktor");
	}
	@Override
	public int sum(int x, int y) {
		return x + y;
	}
}
