Was man nur im Debug-Level des Loggings sehen kann:
In dieser Zusammenstellung der Version verursacht die Hinzuname von LogBack
ein internes ClassNotFound beim Jupiter-Test mit Spring-Support!