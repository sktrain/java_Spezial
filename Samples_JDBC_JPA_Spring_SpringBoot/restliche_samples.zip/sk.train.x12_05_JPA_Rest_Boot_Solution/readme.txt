Spring Data Rest: direkte Bereitstellung der Repositories über REST inklusive HATEOAS.
Das heißt, wir schreiben keine Controller!

Allerdings nur JSON Unterstützung, d.h. xml-Libs sind unnötig.


(Rest mit JPA, Spring Boot und
jetzt kommt noch Spring Data Rest hinzu: weitere Bibliothek als Spring-Starter)