Rest mit JPA, Spring Boot und XML-MessageFormat mit Jackson

Dazu sind weitere Bibliotheken im ClassPath nötig:
jetzt mal mit JAXB statt Jackson,
dann muss allerdings die Entity mit @XmlRootElement markiert sein.

