package sk.train.records;

public class TestRecord {

	public static void main(String[] args) {
		 
		Point p = new Point(2, 2);
		System.out.println(p.x());
		System.out.println(p);
		
		Record1 r1 = new Record1(1, null);
		System.out.println(r1);

	}

}
