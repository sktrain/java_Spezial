package aufgaben_Streams_1;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Aufgabe_2_loes {

	public static void main(String[] args) {

		String[] namesArray = { "Tim", "Tom", "Andy", "Mike", "Merten" };
		List<String> names = Arrays.asList(namesArray);
		
		Stream<String> streamFromArray = Arrays.stream(namesArray);	
		Stream<String> streamFromList = names.stream();	
		Stream<String> streamFromValues = Stream.of("Tim", "Tom", "Andy", "Mike", "Merten");	
		
		
		Stream<String> filtered = streamFromList.filter(name -> name.charAt(0) == 'T');
		Stream<String> mapped = streamFromValues.map(String::toUpperCase);
		
		//Test
//    	filtered.forEach(System.out::println);
//        mapped.forEach(System.out::println);
		
		//mal kombiniert
    	names.stream().filter(name -> name.charAt(0) == 'T').map(String::toUpperCase).forEach(System.out::println);
		
    	
    	//es kommt ein Object[], Cast auf String[] ist nicht moeglich und macht auch keinen Sinn
		Object[] contentsAsArray = names.stream().filter(name -> name.charAt(0) == 'T').map(String::toUpperCase).toArray();
		//String[] contentsAsStringArray = (String[]) names.stream().filter(name -> name.charAt(0) == 'T').map(String::toUpperCase).toArray();
		//deshalb besser
		String[] strings = 
		names.stream().filter(name -> name.charAt(0) == 'T').map(String::toUpperCase).toArray((int i)-> new String[i]);
		// bzw. mit Methodenreferenz
		strings = names.stream().filter(name -> name.charAt(0) == 'T').map(String::toUpperCase).toArray(String[]::new);
		
		final List<String> contentsAsList = names.stream().filter(name -> name.charAt(0) == 'T').map(String::toUpperCase).collect(Collectors.toList());
		
		//nur zum Test
		System.out.println(Arrays.toString(contentsAsArray));
		System.out.println(Arrays.toString(strings));
		System.out.println(contentsAsList);
		

	}

}