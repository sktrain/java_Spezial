package aufgaben_Streams_1;

/**
 * Diese Aufzaehlung definiert ein Geschlecht.
 * 
 * @author Michael Inden
 * 
 * Copyright 2014 by Michael Inden
 */
public enum Gender
{
    MALE, FEMALE;
}