Basisversion der Mitarbeiterklasse
+ angedeutetem JUnit-Test (Jupiter)