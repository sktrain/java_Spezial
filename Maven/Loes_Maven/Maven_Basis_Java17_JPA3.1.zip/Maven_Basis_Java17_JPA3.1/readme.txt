Ein Basis Maven Projekt mit aktuellen Plugin-Versionen vom Januar 2023
+ Jupiter-Dependencies
+ JPA2.2/Hibernate5-Dependencies
+ Oracle JDBC

Debugging kann eingeschaltet werden (bzw. auf höheren Level gesetzt werden) mittels logback.xml:

- Setzen des root-Levels z.Bsp. auf "debug"
