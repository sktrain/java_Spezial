package sk.train.dbzugriff;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbzugriffApplicationTests {

	@Test
	void contextLoads() {
	}

}
