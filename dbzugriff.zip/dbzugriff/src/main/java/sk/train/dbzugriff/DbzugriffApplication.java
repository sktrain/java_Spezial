package sk.train.dbzugriff;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbzugriffApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbzugriffApplication.class, args);
	}

}
